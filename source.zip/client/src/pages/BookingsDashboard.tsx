import { useState, useMemo, useCallback } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import {
  Calendar,
  RefreshCw,
  Home,
  TrendingUp,
  Clock,
  CheckCircle2,
  User,
  Phone,
  Mail,
  Banknote,
  StickyNote,
  ArrowUp,
  ArrowDown,
  ArrowUpDown,
} from "lucide-react";
import { format } from "date-fns";

// ─── Sort helpers ─────────────────────────────────────────────────────────────

type SortKey = "property" | "channel" | "guestName" | "checkIn" | "checkOut" | "nights" | "status" | "depositStatus" | "revenue";
type SortDir = "asc" | "desc";

function SortIcon({ col, sortKey, sortDir }: { col: SortKey; sortKey: SortKey; sortDir: SortDir }) {
  if (col !== sortKey) return <ArrowUpDown className="inline ml-1 h-3 w-3 opacity-40" />;
  return sortDir === "asc"
    ? <ArrowUp className="inline ml-1 h-3 w-3 text-primary" />
    : <ArrowDown className="inline ml-1 h-3 w-3 text-primary" />;
}

// ─── Types ────────────────────────────────────────────────────────────────────

type Booking = {
  id: number;
  property: string;
  channel: string;
  checkIn: Date;
  checkOut: Date;
  status: string;
  depositStatus: string;
  guestName: string | null;
  guestEmail: string | null;
  guestPhone: string | null;
  adultsCount: number | null;
  childrenCount: number | null;
  animalsCount: number | null;
  totalPrice: string | null;
  hostRevenue: string | null;
  currency: string | null;
  transferAmount: string | null;
  transferSender: string | null;
  transferTitle: string | null;
  transferDate: Date | null;
  matchScore: number | null;
  notes: string | null;
  createdAt: Date;
};

// ─── Badge helpers ────────────────────────────────────────────────────────────

function StatusBadge({ status }: { status: string }) {
  const labels: Record<string, string> = {
    pending: "Pending",
    confirmed: "Confirmed",
    paid: "Paid",
    finished: "Finished",
  };
  return (
    <span
      className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border status-${status}`}
    >
      {labels[status] ?? status}
    </span>
  );
}

function DepositBadge({ status }: { status: string }) {
  const labels: Record<string, string> = {
    pending: "Dep: Pending",
    paid: "Dep: Paid",
    returned: "Dep: Returned",
    not_applicable: "Dep: N/A",
  };
  return (
    <span
      className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border deposit-${status}`}
    >
      {labels[status] ?? status}
    </span>
  );
}

function ChannelBadge({ channel }: { channel: string }) {
  const labels: Record<string, string> = {
    slowhop: "Slowhop",
    airbnb: "Airbnb",
    booking: "Booking.com",
    alohacamp: "Alohacamp",
    direct: "Direct",
  };
  return (
    <span
      className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium channel-${channel}`}
    >
      {labels[channel] ?? channel}
    </span>
  );
}

// ─── Booking Detail Modal ─────────────────────────────────────────────────────

function BookingDetailModal({
  booking,
  onClose,
}: {
  booking: Booking;
  onClose: () => void;
}) {
  const utils = trpc.useUtils();
  const updateStatus = trpc.bookings.updateStatus.useMutation({
    onSuccess: () => {
      utils.bookings.list.invalidate();
      utils.bookings.stats.invalidate();
      toast.success("Status updated");
    },
  });
  const updateDeposit = trpc.bookings.updateDeposit.useMutation({
    onSuccess: () => {
      utils.bookings.list.invalidate();
      toast.success("Deposit status updated");
    },
  });
  const updateNotes = trpc.bookings.updateNotes.useMutation({
    onSuccess: () => {
      utils.bookings.list.invalidate();
      toast.success("Notes saved");
    },
  });

  const [notes, setNotes] = useState(booking.notes ?? "");
  const nights = Math.round(
    (new Date(booking.checkOut).getTime() - new Date(booking.checkIn).getTime()) /
      (1000 * 60 * 60 * 24)
  );

  return (
    <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-white dark:bg-zinc-900 border shadow-xl">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2">
          <Home className="h-5 w-5 text-primary" />
          {booking.property} — {booking.guestName ?? "Unknown Guest"}
        </DialogTitle>
      </DialogHeader>

      <div className="grid grid-cols-2 gap-4 mt-2">
        {/* Dates */}
        <div className="col-span-2 bg-muted/50 rounded-lg p-3 grid grid-cols-3 gap-3">
          <div>
            <p className="text-xs text-muted-foreground">Check-in</p>
            <p className="font-semibold">{format(new Date(booking.checkIn), "dd MMM yyyy")}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Check-out</p>
            <p className="font-semibold">{format(new Date(booking.checkOut), "dd MMM yyyy")}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Duration</p>
            <p className="font-semibold">{nights} night{nights !== 1 ? "s" : ""}</p>
          </div>
        </div>

        {/* Channel & Status */}
        <div>
          <p className="text-xs text-muted-foreground mb-1">Channel</p>
          <ChannelBadge channel={booking.channel} />
        </div>
        <div>
          <p className="text-xs text-muted-foreground mb-1">Guests</p>
          <p className="text-sm">
            {booking.adultsCount != null ? `${booking.adultsCount} adults` : "—"}
            {booking.childrenCount ? `, ${booking.childrenCount} children` : ""}
            {booking.animalsCount ? `, ${booking.animalsCount} animals` : ""}
          </p>
        </div>

        {/* Guest details */}
        {booking.guestName && (
          <div className="flex items-center gap-2">
            <User className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm">{booking.guestName}</span>
          </div>
        )}
        {booking.guestPhone && (
          <div className="flex items-center gap-2">
            <Phone className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm">{booking.guestPhone}</span>
          </div>
        )}
        {booking.guestEmail && (
          <div className="col-span-2 flex items-center gap-2">
            <Mail className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm">{booking.guestEmail}</span>
          </div>
        )}

        {/* Pricing */}
        {(booking.totalPrice || booking.hostRevenue) && (
          <div className="col-span-2 bg-muted/50 rounded-lg p-3 grid grid-cols-2 gap-3">
            {booking.totalPrice && (
              <div>
                <p className="text-xs text-muted-foreground">Total Price</p>
                <p className="font-semibold">
                  {parseFloat(booking.totalPrice).toLocaleString("pl-PL")} {booking.currency ?? "PLN"}
                </p>
              </div>
            )}
            {booking.hostRevenue && (
              <div>
                <p className="text-xs text-muted-foreground">Host Revenue</p>
                <p className="font-semibold text-green-700">
                  {parseFloat(booking.hostRevenue).toLocaleString("pl-PL")} {booking.currency ?? "PLN"}
                </p>
              </div>
            )}
          </div>
        )}

        {/* Transfer info */}
        {booking.transferSender && (
          <div className="col-span-2 border rounded-lg p-3">
            <div className="flex items-center gap-2 mb-2">
              <Banknote className="h-4 w-4 text-muted-foreground" />
              <p className="text-sm font-medium">Bank Transfer</p>
              {booking.matchScore != null && (
                <span className="text-xs text-muted-foreground ml-auto">
                  Match score: {booking.matchScore}%
                </span>
              )}
            </div>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div>
                <p className="text-xs text-muted-foreground">From</p>
                <p>{booking.transferSender}</p>
              </div>
              {booking.transferAmount && (
                <div>
                  <p className="text-xs text-muted-foreground">Amount</p>
                  <p>{parseFloat(booking.transferAmount).toLocaleString("pl-PL")} PLN</p>
                </div>
              )}
              {booking.transferTitle && (
                <div className="col-span-2">
                  <p className="text-xs text-muted-foreground">Title</p>
                  <p className="text-xs">{booking.transferTitle}</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Status controls */}
        <div>
          <p className="text-xs text-muted-foreground mb-1">Booking Status</p>
          <Select
            value={booking.status}
            onValueChange={(v) =>
              updateStatus.mutate({
                id: booking.id,
                status: v as "pending" | "confirmed" | "paid" | "finished",
              })
            }
          >
            <SelectTrigger className="h-8 text-sm">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="confirmed">Confirmed</SelectItem>
              <SelectItem value="paid">Paid</SelectItem>
              <SelectItem value="finished">Finished</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <p className="text-xs text-muted-foreground mb-1">Deposit Status</p>
          <Select
            value={booking.depositStatus}
            onValueChange={(v) =>
              updateDeposit.mutate({
                id: booking.id,
                depositStatus: v as "pending" | "paid" | "returned" | "not_applicable",
              })
            }
          >
            <SelectTrigger className="h-8 text-sm">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="paid">Paid</SelectItem>
              <SelectItem value="returned">Returned</SelectItem>
              <SelectItem value="not_applicable">Not Applicable</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Notes */}
        <div className="col-span-2">
          <div className="flex items-center gap-2 mb-1">
            <StickyNote className="h-4 w-4 text-muted-foreground" />
            <p className="text-xs text-muted-foreground">Notes</p>
          </div>
          <textarea
            className="w-full border rounded-md p-2 text-sm resize-none h-20 focus:outline-none focus:ring-2 focus:ring-ring bg-background"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Add notes about this booking..."
          />
          <Button
            size="sm"
            variant="outline"
            className="mt-1"
            onClick={() => updateNotes.mutate({ id: booking.id, notes })}
          >
            Save Notes
          </Button>
        </div>
      </div>
    </DialogContent>
  );
}

// ─── Stats Cards ──────────────────────────────────────────────────────────────

function StatsCards() {
  const { data: stats } = trpc.bookings.stats.useQuery();

  if (!stats) return null;

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
      <Card className="border-0 shadow-sm">
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-blue-100 flex items-center justify-center">
              <Calendar className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <p className="text-2xl font-bold">{stats.total}</p>
              <p className="text-xs text-muted-foreground">Total Bookings</p>
            </div>
          </div>
        </CardContent>
      </Card>
      <Card className="border-0 shadow-sm">
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-amber-100 flex items-center justify-center">
              <Clock className="h-5 w-5 text-amber-600" />
            </div>
            <div>
              <p className="text-2xl font-bold">{stats.upcoming}</p>
              <p className="text-xs text-muted-foreground">Upcoming</p>
            </div>
          </div>
        </CardContent>
      </Card>
      <Card className="border-0 shadow-sm">
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-green-100 flex items-center justify-center">
              <CheckCircle2 className="h-5 w-5 text-green-600" />
            </div>
            <div>
              <p className="text-2xl font-bold">{stats.paid}</p>
              <p className="text-xs text-muted-foreground">Paid</p>
            </div>
          </div>
        </CardContent>
      </Card>
      <Card className="border-0 shadow-sm">
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-teal-100 flex items-center justify-center">
              <TrendingUp className="h-5 w-5 text-teal-600" />
            </div>
            <div>
              <p className="text-2xl font-bold">
                {stats.totalRevenue.toLocaleString("pl-PL")}
              </p>
              <p className="text-xs text-muted-foreground">Revenue (PLN)</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// ─── Main Dashboard ───────────────────────────────────────────────────────────

export default function BookingsDashboard() {
  const [property, setProperty] = useState<string>("all");
  const [channel, setChannel] = useState<string>("all");
  const [status, setStatus] = useState<string>("all");
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
  const [sortKey, setSortKey] = useState<SortKey>("checkIn");
  const [sortDir, setSortDir] = useState<SortDir>("asc");

  const handleSort = useCallback((col: SortKey) => {
    setSortKey(prev => {
      if (prev === col) {
        setSortDir(d => d === "asc" ? "desc" : "asc");
        return col;
      }
      setSortDir("asc");
      return col;
    });
  }, []);

  const filters = useMemo(
    () => ({
      property: property !== "all" ? (property as "Sadoles" | "Hacjenda") : undefined,
      channel:
        channel !== "all"
          ? (channel as "slowhop" | "airbnb" | "booking" | "alohacamp" | "direct")
          : undefined,
      status:
        status !== "all"
          ? (status as "pending" | "confirmed" | "paid" | "finished")
          : undefined,
    }),
    [property, channel, status]
  );

  const { data: rawBookingList = [], isLoading, refetch } = trpc.bookings.list.useQuery(filters);

  const nightsCount = (b: { checkIn: Date; checkOut: Date }) =>
    Math.round((new Date(b.checkOut).getTime() - new Date(b.checkIn).getTime()) / (1000 * 60 * 60 * 24));

  const bookingList = useMemo(() => {
    return [...rawBookingList].sort((a, b) => {
      let aVal: string | number = 0;
      let bVal: string | number = 0;
      switch (sortKey) {
        case "property":      aVal = a.property ?? ""; bVal = b.property ?? ""; break;
        case "channel":       aVal = a.channel ?? ""; bVal = b.channel ?? ""; break;
        case "guestName":     aVal = a.guestName ?? ""; bVal = b.guestName ?? ""; break;
        case "checkIn":       aVal = new Date(a.checkIn).getTime(); bVal = new Date(b.checkIn).getTime(); break;
        case "checkOut":      aVal = new Date(a.checkOut).getTime(); bVal = new Date(b.checkOut).getTime(); break;
        case "nights":        aVal = nightsCount(a as { checkIn: Date; checkOut: Date }); bVal = nightsCount(b as { checkIn: Date; checkOut: Date }); break;
        case "status":        aVal = a.status ?? ""; bVal = b.status ?? ""; break;
        case "depositStatus": aVal = a.depositStatus ?? ""; bVal = b.depositStatus ?? ""; break;
        case "revenue":       aVal = parseFloat(a.hostRevenue ?? a.totalPrice ?? "0") || 0; bVal = parseFloat(b.hostRevenue ?? b.totalPrice ?? "0") || 0; break;
      }
      if (aVal < bVal) return sortDir === "asc" ? -1 : 1;
      if (aVal > bVal) return sortDir === "asc" ? 1 : -1;
      return 0;
    });
  }, [rawBookingList, sortKey, sortDir]);
  const utils = trpc.useUtils();

  const triggerIcal = trpc.sync.triggerIcal.useMutation({
    onSuccess: () => {
      utils.bookings.list.invalidate();
      utils.bookings.stats.invalidate();
      toast.success("iCal sync complete");
    },
    onError: (e) => toast.error(`Sync failed: ${e.message}`),
  });

  const triggerEmail = trpc.sync.triggerEmail.useMutation({
    onSuccess: (data) => {
      utils.bookings.list.invalidate();
      utils.bookings.stats.invalidate();
      toast.success(
        `Email check complete — ${data.enriched} enriched, ${data.matched} matched`
      );
    },
    onError: (e) => toast.error(`Email check failed: ${e.message}`),
  });

  return (
    <DashboardLayout>
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Bookings</h1>
            <p className="text-sm text-muted-foreground mt-0.5">
              Sadoleś &amp; Hacjenda — all channels
            </p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => triggerEmail.mutate()}
              disabled={triggerEmail.isPending}
            >
              <Mail className="h-4 w-4 mr-1.5" />
              {triggerEmail.isPending ? "Checking..." : "Check Email"}
            </Button>
            <Button
              size="sm"
              onClick={() => triggerIcal.mutate()}
              disabled={triggerIcal.isPending}
            >
              <RefreshCw
                className={`h-4 w-4 mr-1.5 ${triggerIcal.isPending ? "animate-spin" : ""}`}
              />
              {triggerIcal.isPending ? "Syncing..." : "Sync iCal"}
            </Button>
          </div>
        </div>

        {/* Stats */}
        <StatsCards />

        {/* Filters */}
        <div className="flex flex-wrap gap-2 mb-4">
          <Select value={property} onValueChange={setProperty}>
            <SelectTrigger className="w-36 h-8 text-sm">
              <SelectValue placeholder="Property" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Properties</SelectItem>
              <SelectItem value="Sadoles">Sadoleś</SelectItem>
              <SelectItem value="Hacjenda">Hacjenda</SelectItem>
            </SelectContent>
          </Select>

          <Select value={channel} onValueChange={setChannel}>
            <SelectTrigger className="w-36 h-8 text-sm">
              <SelectValue placeholder="Channel" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Channels</SelectItem>
              <SelectItem value="slowhop">Slowhop</SelectItem>
              <SelectItem value="airbnb">Airbnb</SelectItem>
              <SelectItem value="booking">Booking.com</SelectItem>
              <SelectItem value="alohacamp">Alohacamp</SelectItem>
              <SelectItem value="direct">Direct</SelectItem>
            </SelectContent>
          </Select>

          <Select value={status} onValueChange={setStatus}>
            <SelectTrigger className="w-36 h-8 text-sm">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="confirmed">Confirmed</SelectItem>
              <SelectItem value="paid">Paid</SelectItem>
              <SelectItem value="finished">Finished</SelectItem>
            </SelectContent>
          </Select>

          <span className="ml-auto text-sm text-muted-foreground self-center">
            {bookingList.length} booking{bookingList.length !== 1 ? "s" : ""}
          </span>
        </div>

        {/* Table */}
        <Card className="border-0 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-muted/40">
                  {([
                    ["property", "Property"],
                    ["channel", "Channel"],
                    ["guestName", "Guest"],
                    ["checkIn", "Check-in"],
                    ["checkOut", "Check-out"],
                    ["nights", "Nights"],
                    ["status", "Status"],
                    ["depositStatus", "Deposit"],
                    ["revenue", "Revenue"],
                  ] as [SortKey, string][]).map(([col, label]) => (
                    <th key={col} className="text-left px-4 py-3 font-medium text-muted-foreground">
                      <button
                        onClick={() => handleSort(col)}
                        className="flex items-center gap-0.5 hover:text-foreground transition-colors select-none whitespace-nowrap"
                      >
                        {label}
                        <SortIcon col={col} sortKey={sortKey} sortDir={sortDir} />
                      </button>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {isLoading && (
                  <tr>
                    <td colSpan={9} className="text-center py-12 text-muted-foreground">
                      Loading bookings...
                    </td>
                  </tr>
                )}
                {!isLoading && bookingList.length === 0 && (
                  <tr>
                    <td colSpan={9} className="text-center py-12 text-muted-foreground">
                      <div className="flex flex-col items-center gap-2">
                        <Calendar className="h-8 w-8 opacity-30" />
                        <p>No bookings found</p>
                        <p className="text-xs">Click "Sync iCal" to import bookings from your calendars</p>
                      </div>
                    </td>
                  </tr>
                )}
                {bookingList.map((b) => (
                  <tr
                    key={b.id}
                    className="border-b last:border-0 hover:bg-muted/30 cursor-pointer transition-colors"
                    onClick={() => setSelectedBooking(b as Booking)}
                  >
                    <td className="px-4 py-3 font-medium">
                      {b.property === "Sadoles" ? "Sadoleś" : b.property}
                    </td>
                    <td className="px-4 py-3">
                      <ChannelBadge channel={b.channel} />
                    </td>
                    <td className="px-4 py-3">
                      {b.guestName ?? (
                        <span className="text-muted-foreground italic text-xs">No name yet</span>
                      )}
                    </td>
                    <td className="px-4 py-3 tabular-nums">
                      {format(new Date(b.checkIn), "dd MMM yyyy")}
                    </td>
                    <td className="px-4 py-3 tabular-nums">
                      {format(new Date(b.checkOut), "dd MMM yyyy")}
                    </td>
                    <td className="px-4 py-3 tabular-nums text-center">
                      {nightsCount(b as { checkIn: Date; checkOut: Date })}
                    </td>
                    <td className="px-4 py-3">
                      <StatusBadge status={b.status} />
                    </td>
                    <td className="px-4 py-3">
                      <DepositBadge status={b.depositStatus} />
                    </td>
                    <td className="px-4 py-3 tabular-nums">
                      {b.hostRevenue
                        ? `${parseFloat(b.hostRevenue).toLocaleString("pl-PL")} PLN`
                        : b.totalPrice
                        ? `${parseFloat(b.totalPrice).toLocaleString("pl-PL")} PLN`
                        : "—"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </div>

      {/* Booking detail modal */}
      <Dialog open={!!selectedBooking} onOpenChange={(open) => !open && setSelectedBooking(null)}>
        {selectedBooking && (
          <BookingDetailModal
            booking={selectedBooking}
            onClose={() => setSelectedBooking(null)}
          />
        )}
      </Dialog>
    </DashboardLayout>
  );
}
