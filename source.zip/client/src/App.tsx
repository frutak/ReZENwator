import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import BookingsDashboard from "./pages/BookingsDashboard";
import SyncStatus from "./pages/SyncStatus";
import CalendarView from "./pages/CalendarView";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={BookingsDashboard} />
      <Route path={"/calendar"} component={CalendarView} />
      <Route path={"/sync"} component={SyncStatus} />
      <Route path={"/404"} component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
