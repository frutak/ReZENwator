import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import {
  getBookings,
  getBookingById,
  updateBookingStatus,
  updateDepositStatus,
  updateBookingNotes,
  getBookingStats,
  getRecentSyncLogs,
  getLastSyncTime,
} from "./db";
import { pollAllICalFeeds, pollICalFeed } from "./workers/icalPoller";
import { pollEmails } from "./workers/emailPoller";
import { findMatchingBookings, applyTransferMatch } from "./workers/bookingMatcher";
import { ICAL_FEEDS } from "./workers/icalConfig";
import { getDb } from "./db";
import { bookings } from "../drizzle/schema";
import { eq } from "drizzle-orm";

// ─── Booking router ───────────────────────────────────────────────────────────

const bookingRouter = router({
  list: publicProcedure
    .input(
      z.object({
        property: z.enum(["Sadoles", "Hacjenda"]).optional(),
        channel: z.enum(["slowhop", "airbnb", "booking", "alohacamp", "direct"]).optional(),
        status: z.enum(["pending", "confirmed", "paid", "finished"]).optional(),
        depositStatus: z.enum(["pending", "paid", "returned", "not_applicable"]).optional(),
        checkInFrom: z.coerce.date().optional(),
        checkInTo: z.coerce.date().optional(),
        limit: z.number().min(1).max(500).default(200),
        offset: z.number().min(0).default(0),
      }).optional()
    )
    .query(async ({ input }) => {
      return getBookings(input ?? {});
    }),

  get: publicProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      return getBookingById(input.id);
    }),

  stats: publicProcedure.query(async () => {
    return getBookingStats();
  }),

  updateStatus: publicProcedure
    .input(
      z.object({
        id: z.number(),
        status: z.enum(["pending", "confirmed", "paid", "finished"]),
      })
    )
    .mutation(async ({ input }) => {
      await updateBookingStatus(input.id, input.status);
      return { success: true };
    }),

  updateDeposit: publicProcedure
    .input(
      z.object({
        id: z.number(),
        depositStatus: z.enum(["pending", "paid", "returned", "not_applicable"]),
      })
    )
    .mutation(async ({ input }) => {
      await updateDepositStatus(input.id, input.depositStatus);
      return { success: true };
    }),

  updateNotes: publicProcedure
    .input(
      z.object({
        id: z.number(),
        notes: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      await updateBookingNotes(input.id, input.notes);
      return { success: true };
    }),

  /** Manually apply a bank transfer match to a booking */
  applyTransferMatch: publicProcedure
    .input(
      z.object({
        bookingId: z.number(),
        transferAmount: z.number().optional(),
        transferSender: z.string().optional(),
        transferTitle: z.string().optional(),
        transferDate: z.coerce.date().optional(),
        score: z.number().default(100),
      })
    )
    .mutation(async ({ input }) => {
      await applyTransferMatch(
        input.bookingId,
        {
          type: "bank",
          bank: "nestbank",
          amount: input.transferAmount,
          senderName: input.transferSender,
          transferTitle: input.transferTitle,
          transferDate: input.transferDate,
          rawText: "",
        },
        input.score
      );
      return { success: true };
    }),
});

// ─── Sync router ──────────────────────────────────────────────────────────────

const syncRouter = router({
  triggerIcal: publicProcedure.mutation(async () => {
    const result = await pollAllICalFeeds();
    return { success: true, message: "iCal sync triggered" };
  }),

  triggerEmail: publicProcedure.mutation(async () => {
    const result = await pollEmails();
    return {
      success: true,
      processed: result.processed,
      enriched: result.enriched,
      matched: result.matched,
      errors: result.errors,
    };
  }),

  lastRun: publicProcedure.query(async () => {
    const [icalLast, emailLast] = await Promise.all([
      getLastSyncTime("ical"),
      getLastSyncTime("email"),
    ]);
    return { ical: icalLast, email: emailLast };
  }),

  logs: publicProcedure
    .input(z.object({ limit: z.number().min(1).max(100).default(20) }).optional())
    .query(async ({ input }) => {
      return getRecentSyncLogs(input?.limit ?? 20);
    }),

  feeds: publicProcedure.query(() => {
    return ICAL_FEEDS.map((f) => ({
      label: f.label,
      property: f.property,
      channel: f.channel,
    }));
  }),
});

// ─── App router ───────────────────────────────────────────────────────────────

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  bookings: bookingRouter,
  sync: syncRouter,
});

export type AppRouter = typeof appRouter;
